﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BuscaTexto
{
    class BoyerMoore
    {
        static int[] skip = new int[256];

        public static void initSkip(String p)
        {
            int j, m = p.Length;
            for (j = 0; j < 256; j++)
            {
                skip[j] = m;
            }
            for (j = 0; j < m; j++)
            {
                skip[p[j]] = m - j - 1;
            }
        }

        public static int BMSearch(String p, String t, RichTextBox w)
        {
            int i, j, a, m = p.Length, n = t.Length;
            i = m - 1; // tam do pal -1
            j = m - 1; // tam do pal -1 
            initSkip(p);
            while (i != n)
            {
                while (j >= 0)
                {
                    while (t[i] != p[j])
                    {
                        a = skip[t[i]];
                        i += (m - j > a) ? (m - j) : a;
                        if (i >= n)
                        {
                            break;
                        }
                        j = m - 1;
                    }
                    i--;
                    j--;
                }
                //Posiçao inicial para iniciar o colorimento das palavras 
                w.SelectionStart = i + 1;
                w.SelectionLength = m; // background largueza  
                w.SelectionBackColor = Color.Blue;
                i += m + 1; // acrescentando no i o tamanho da sentenca + um 
                j = m - 1; // resetando j para que o metodo trbalhe da maneira corrta
            } 
            return 1;  
        }
    }
}
