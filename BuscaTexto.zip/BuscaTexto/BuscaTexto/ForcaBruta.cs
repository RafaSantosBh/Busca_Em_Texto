﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Schema;

namespace BuscaTexto
{
    class ForcaBruta
    {
        public static int forcaBruta(String p, String t, RichTextBox w)
        {
            int i, j, aux;
            int m = p.Length;
            int n = t.Length;

            for (i = 0; i < n; i++)
            {
                aux = i;
                for (j = 0; j < m && aux < n; j++)
                {

                    if (t[aux] != p[j])
                    {
                        if (p[j] == '?')
                        {
                            p.Replace(p[j], t[aux]);
                        }
                        else
                        {
                            break; 
                        }
                    }
                    aux++;
                }
                if (j == m)
                {
                    //Posiçao inicial para iniciar o colorimento das palavras 
                    w.SelectionStart = i;
                    w.SelectionLength = j; // background largueza
                    w.SelectionBackColor = Color.Blue;
                }
            }

            return -1;   
        }
    }
}